////////////////////////////////////////////////////////////////
// main.cpp
//
// Forward-compatible core GL 4.3 version
//
// This creates an awesome game.
//
// Cody Valle
////////////////////////////////////////////////////////////////

#include <cmath>
#include <iostream>
#include <fstream>

#include <GL/glew.h>
#include <GL/freeglut.h>

#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "drawableFactory.h"
#include "rootNode.h"
#include "ellipticalAnimator.h"
#include "shipController.h"

#include "collisionDetection.h"

using namespace std;
using namespace glm;

// Globals.
static bool isAnimate = true; // Animated?
static unsigned animationPeriod = 10; // Time interval between frames in milliseconds.

// Drawable Factory
static DrawableFactory* drawableFactory = 0;

// Root node
static RootNode* root = 0;

// If a button is pressed
static KeyInput* keys = new KeyInput();

// For checking collisions
static CollisionDetector* collisionDetector = 0;

// For tracking deltaTime
static float old_t;

// Drawing routine.
void drawScene(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Draw the scene
    if (root)
        root->draw(mat4(1.0));

    glutSwapBuffers();
}

// Timer function.
void animate(int value)
{
    if (isAnimate)
    {
        int t = glutGet(GLUT_ELAPSED_TIME);

        if (root)
            root->animate((t - old_t) / 10.0); // Update all animations

        old_t = t;
        glutPostRedisplay();
        glutTimerFunc(animationPeriod, animate, value);
    }
}

// Initialization routine.
int setup(void)
{
    // Create a DrawableFactory
    drawableFactory = new DrawableFactory();

    /// Set up the main ship
    Node* shipParentNode = new Node();
    shipParentNode->getTransform().setTranslate(vec3(0., 0., -30.));
    // Set up the shooting capabilities
    BulletController* bulletController = new BulletController(drawableFactory, root, -130.);
    // Create an animator
    Animator* shipController = new ShipController(shipParentNode->getTransform(), keys, bulletController);
    root->addChild(shipParentNode, shipController);

    // Create the wings
    Node* wingsNode = new Node();
    shipParentNode->addChild(wingsNode);
    // Add the wings
    Drawable* wingsObj = drawableFactory->makeSphere(1., 4., 4.);
    wingsNode->addDrawable(wingsObj);
    // Change the color
    float wingsColor[] = {.5, 0.8, 0.5, 1.};
    wingsObj->setColor(wingsColor);
    // Change the shape
    wingsNode->getTransform().setScale(vec3(6., 0.2, .6));

    // Create the body
    Node* bodyNode = new Node();
    shipParentNode->addChild(bodyNode);
    // Add the body
    Drawable* bodyObj = drawableFactory->makeSphere(2., 4., 4.);
    bodyNode->addDrawable(bodyObj);
    // Change the color
    float bodyColor[] = {.5, 0.3, 0.5, 1.};
    bodyObj->setColor(bodyColor);
    // Change the shape
    bodyNode->getTransform().setScale(vec3(1., 1., 2.));


    /// Set up the sun
    Node* sunNode = new Node();
    sunNode->getTransform().setTranslate(vec3(0, 0, -80));
    root->addChild(sunNode);
    // Create the sun
    Drawable* sun = drawableFactory->makeSphere(5., 15., 10.);
    float sunColor[] = {1., 1., 0.3, 1.};
    sun->setColor(sunColor);
    sunNode->addDrawable(sun);

    // Set up the collider
    BoundingBox* sunBBox = new BoundingBox(5., 5., 5.);
    Collider* collider = new Collider(sunNode, sunBBox);
    collisionDetector->addCollider(collider);
/*
    /// Set up the planet
    // Create the planet
    Node* planetNode = new Node();
    // Its Transform is controlled by an elliptical animation
    Animator* anim = new EllipticalAnimator(planetNode->getTransform(), 27, 17, PI / 128, PI / 3);
    // Planet is child of sun
    sunNode->addChild(planetNode, anim);

    // Add the planet Sphere to the Node
    Drawable* planet = drawableFactory->makeSphere(2., 10, 5);
    float planetColor[] = {0.2, 0.2, 0.9, 1.};
    planet->setColor(planetColor);
    planetNode->addDrawable(planet);

    /// Set up the close moon
    // Create the first moon
    Node* moon1Node = new Node();
    // Create its animation
    anim = new EllipticalAnimator(moon1Node->getTransform(), 11, 9.5, PI / 60);
    // Moon is child of planet
    planetNode->addChild(moon1Node, anim);

    // Add the moon Sphere to the Node
    Drawable* moon1 = drawableFactory->makeSphere(1., 8, 4);
    float moon1Color[] = {0.3, 0.8, 0.3, 1.0};
    moon1->setColor(moon1Color);
    moon1Node->addDrawable(moon1);

    /// Set up the far moon
    // Create the second moon
    Node* moon2Node = new Node();
    // Create its animation
    anim = new EllipticalAnimator(moon2Node->getTransform(), 6, 7, -PI / 80);
    // Moon is child of planet
    planetNode->addChild(moon2Node, anim);

    // Add the moon Sphere to the Node
    Drawable* moon2 = drawableFactory->makeSphere(1., 8, 4);
    float moon2Color[] = {0.4, 0.9, 0.7, 1.0};
    moon2->setColor(moon2Color);
    moon2Node->addDrawable(moon2);

    /// Add Halley's Comet
    Node* cometNode = new Node();
    anim = new EllipticalAnimator(cometNode->getTransform(), 70, 30, PI / 300);
    anim->setTranslation(vec3(60, 0, 0));
    sunNode->addChild(cometNode, anim);

    Drawable* comet = drawableFactory->makeSphere(0.7, 5, 5);
    float cometColor[] = {0.8, 0.3, 0.3, 1.0};
    comet->setColor(cometColor);
    cometNode->addDrawable(comet);

    /// Add asteroids
    float asteroidColor[] = {0.5, 0.5, 0.5, 1.0};
    const int numAsteroids = 100;

    for (float j = 0; j < numAsteroids / 10.; ++j)
        for (int i = 0; i < numAsteroids; ++i)
        {
            Node* asteroidNode = new Node();
            float radius = j / numAsteroids * 100.0 + 40.0;
            anim = new EllipticalAnimator(asteroidNode->getTransform(), radius, radius, PI / 500, PI * 2 * float(i) / numAsteroids);
            sunNode->addChild(asteroidNode, anim);

            Drawable* asteroid = drawableFactory->makeSphere(0.2, 3, 3);
            asteroid->setColor(asteroidColor);
            asteroidNode->addDrawable(asteroid);
        }
    */
    // Animation on by default
    if (isAnimate)
        animate(1);

    return 0;
}

// OpenGL window reshape routine.
void resize(int w, int h)
{
    glViewport(0, 0, w, h);
}

// Keyboard input processing routine.
void keyUp(unsigned char key, int x, int y)
{
    keys->keyUp(key);
}

// Keyboard input processing routine.
void keyDown(unsigned char key, int x, int y)
{
    keys->keyDown(key);
}

// Routine to output interaction instructions to the C++ window.
void printInteraction(void)
{
    cout << "Interaction:" << endl
         << "Press space to shoot." << endl
         << "Press the WASD keys to move." << endl;
}

// Main routine.
int main(int argc, char **argv)
{
    printInteraction();

    glutInit(&argc, argv);

    glutInitContextVersion(4, 3);
    glutInitContextProfile(GLUT_CORE_PROFILE);
    glutInitContextFlags(GLUT_FORWARD_COMPATIBLE);

    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("SpaceNox");
    //glutFullScreen();
    glutDisplayFunc(drawScene);
    glutReshapeFunc(resize);
    glutKeyboardFunc(keyDown);
    glutKeyboardUpFunc(keyUp);

    glewExperimental = GL_TRUE;
    glewInit();

    glClearColor(0.2, 0.2, 0.2, 1.0);
    glEnable(GL_DEPTH_TEST);

    root = RootNode::getInstance();
    collisionDetector = CollisionDetector::getInstance();

    int ret = setup();
    if (ret) return ret;

    old_t = glutGet(GLUT_ELAPSED_TIME);
    glutMainLoop();
}


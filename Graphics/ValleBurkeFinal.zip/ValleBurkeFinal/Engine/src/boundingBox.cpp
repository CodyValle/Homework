#include "boundingBox.h"

BoundingBox::BoundingBox(float width, float height, float depth) :
        width(width),
        height(height),
        depth(depth)
    {
    }

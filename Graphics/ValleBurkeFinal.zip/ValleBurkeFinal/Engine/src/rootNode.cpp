#include "rootNode.h"

RootNode* RootNode::instance;

RootNode::RootNode()
{
}

RootNode::~RootNode()
{
}

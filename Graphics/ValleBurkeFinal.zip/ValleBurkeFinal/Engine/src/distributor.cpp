#include "distributor.h"

Distributor::Distributor()
{
}

Distributor::~Distributor()
{
}

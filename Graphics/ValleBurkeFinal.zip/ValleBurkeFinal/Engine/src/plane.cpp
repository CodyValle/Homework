#include "plane.h"

Plane::Plane(const unsigned pid) :
    Drawable(pid)
{
}

Plane::~Plane()
{
}


#include "animator.h"

Animator::Animator()
{
}

Animator::~Animator()
{
}

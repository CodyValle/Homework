#ifndef GLOBALS_H_INCLUDED
#define GLOBALS_H_INCLUDED

// Globals

static const double PI = 3.14159265358979;

#endif // GLOBALS_H_INCLUDED

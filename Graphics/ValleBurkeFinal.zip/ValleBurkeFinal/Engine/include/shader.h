#ifndef SHADER_H
#define SHADER_H

// Loads the shader for compilation

int setShader(const char* shaderType, const char* shaderFile);

#endif

"""
Cody Valle, Andrew Burke, Katreina Carpenter
Data Mining Homework 7 Program
"""

global CLASS
CLASS = 0
global AGE
AGE = 1
global SEX
SEX = 2
global SURVIVED
SURVIVED = 3

""" Reads a csv file and returns a table (list of lists) """
def read_csv(filename):
    import csv
    with open(filename, 'r') as the_file:
        return [row for row in csv.reader(the_file, dialect='excel') if len(row) > 0]

""" Gets a list of all different categorical values """
def get_categories(table, index):
    return set([row[index] for row in table if row[index] != None])

""" Counts occurences of an element in a column """
def count_occurences(table, index, value):
    return sum([1 for row in table if row[index] == value])

""" Partitions the passed in table into k folds """
def partition_into_folds(table, k, class_index):
    folds = [[] for _ in range(k)] # Create disjoint empty lists
    table.sort(key=lambda x: x[class_index]) # Sort by class_index
    for row in table:
        folds[random.choice(range(k))].append(row)

    return folds

""" Creates a testing set and training set from a list of folds, on the index of the test fold """
def create_test_and_train_from_folds(folds, index):
    return [folds[j] for j in range(len(folds)) if j != index], folds[index]

""" Creates a set of rules of the form (L,R) from the passed in table using the passed in attribute indices """
def mine_rules(table, attrs):
    rules = []
    for i in range(len(attrs)):
        L,R = [attrs[j] for j in range(len(attrs)) if j != i], attrs[i]
        #if len(L) > 1:
        #    rules += mine_rules(table, L)
        rules.append((L,R))
    return rules

""" Creates a power set """
# Taken from http://stackoverflow.com/questions/1482308/whats-a-good-way-to-combinate-through-a-set
def powerset(iterable):
    s = list(iterable)
    return chain.from_iterable(combinations(s, r) for r in range(len(s)+1))

""" The main method """
def main():    
    titanic_table = read_csv('titanic.txt')
    titanic_labels = titanic_table[0]
    titanic_table = titanic_table[1:]
    #rules = mine_rules(titanic_table, [CLASS, AGE])

    power = powerset([CLASS, AGE])
    for row in power:
        print row

""" To make this an executable """
if __name__ == '__main__':
    main()
